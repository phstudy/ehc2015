mvn clean install
mv RImpala-1.0.jar ../inst/java/RImpala-1.0.jar
